package com.example.assignment11;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ShoppingCartTest {

    // 1. Adding items increases total price correctly
    @Test
    void testAddItemIncreasesTotalPrice() {
        ShoppingCart cart = new ShoppingCart();
        cart.addItem("Book", 200.0);
        cart.addItem("Pen", 50.0);

        assertEquals(250.0, cart.getTotalPrice());
    }

    // 2. Removing item decreases total price correctly
    @Test
    void testRemoveItemDecreasesTotalPrice() {
        ShoppingCart cart = new ShoppingCart();
        cart.addItem("Book", 200.0);
        cart.addItem("Pen", 50.0);

        cart.removeItem("Pen");

        assertEquals(200.0, cart.getTotalPrice());
    }

    // 3. Removing non-existent item throws exception
    @Test
    void testRemoveNonExistentItemThrowsException() {
        ShoppingCart cart = new ShoppingCart();
        cart.addItem("Book", 200.0);

        assertThrows(IllegalArgumentException.class,
                () -> cart.removeItem("Laptop"));
    }

    // 4. Cart handles multiple items correctly
    @Test
    void testMultipleItemsHandledCorrectly() {
        ShoppingCart cart = new ShoppingCart();
        cart.addItem("Book", 200.0);
        cart.addItem("Pen", 50.0);
        cart.addItem("Notebook", 150.0);

        assertEquals(400.0, cart.getTotalPrice());
    }

    // 5. Empty cart returns total price = 0
    @Test
    void testEmptyCartReturnsZero() {
        ShoppingCart cart = new ShoppingCart();

        assertEquals(0.0, cart.getTotalPrice());
    }
}