package com.example.assignment5;

import java.util.ArrayList;
import java.util.List;

public class StudentGradeCalculator {

    private final List<Integer> marks = new ArrayList<>();

    public void addMarks(int marks) {
        if (marks < 0) {
            throw new IllegalArgumentException("Marks cannot be negative");
        }
        this.marks.add(marks);
    }

    public double calculateAverage() {
        if (marks.isEmpty()) {
            return 0.0;
        }

        int sum = 0;
        for (int mark : marks) {
            sum += mark;
        }

        return (double) sum / marks.size();
    }

    public String getResult() {
        double average = calculateAverage();
        return average >= 40 ? "PASS" : "FAIL";
    }
}