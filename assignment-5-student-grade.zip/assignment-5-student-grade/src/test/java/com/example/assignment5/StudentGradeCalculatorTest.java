package com.example.assignment5;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class StudentGradeCalculatorTest {

    // 1. Verify that average is calculated correctly
    @Test
    void testAverageCalculation() {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        calculator.addMarks(50);
        calculator.addMarks(60);
        calculator.addMarks(70);

        assertEquals(60.0, calculator.calculateAverage());
    }

    // 2. Ensure PASS when average ≥ 40
    @Test
    void testPassCondition() {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        calculator.addMarks(40);
        calculator.addMarks(50);

        assertEquals("PASS", calculator.getResult());
    }

    // 3. Ensure FAIL when average < 40
    @Test
    void testFailCondition() {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        calculator.addMarks(20);
        calculator.addMarks(30);

        assertEquals("FAIL", calculator.getResult());
    }

    // 4. Check negative marks throws exception
    @Test
    void testNegativeMarksThrowsException() {
        StudentGradeCalculator calculator = new StudentGradeCalculator();

        assertThrows(IllegalArgumentException.class,
                () -> calculator.addMarks(-10));
    }

    // 5. Verify behavior when no marks are added
    @Test
    void testNoMarksAdded() {
        StudentGradeCalculator calculator = new StudentGradeCalculator();

        assertEquals(0.0, calculator.calculateAverage());
        assertEquals("FAIL", calculator.getResult());
    }
}