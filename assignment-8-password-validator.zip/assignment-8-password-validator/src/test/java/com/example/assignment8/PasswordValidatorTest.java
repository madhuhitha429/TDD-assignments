package com.example.assignment8;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PasswordValidatorTest {

    private final PasswordValidator validator = new PasswordValidator();

    // 1. Verify valid password passes
    @Test
    void testValidPassword() {
        assertTrue(validator.isValid("StrongP@ss1"));
    }

    // 2. Password shorter than 8 characters fails
    @Test
    void testShortPasswordFails() {
        assertFalse(validator.isValid("Ab1@"));
    }

    // 3. Password without uppercase fails
    @Test
    void testNoUppercaseFails() {
        assertFalse(validator.isValid("strongp@ss1"));
    }

    // 4. Password without digits fails
    @Test
    void testNoDigitFails() {
        assertFalse(validator.isValid("StrongPass@"));
    }

    // 5. Password without special character fails
    @Test
    void testNoSpecialCharacterFails() {
        assertFalse(validator.isValid("StrongPass1"));
    }
}