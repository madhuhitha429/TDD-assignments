package com.example.assignment10;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TemperatureConverterTest {

    private final TemperatureConverter converter = new TemperatureConverter();

    // 1. Verify Celsius to Fahrenheit for known values
    @Test
    void testCelsiusToFahrenheit() {
        assertEquals(212.0, converter.celsiusToFahrenheit(100));
        assertEquals(68.0, converter.celsiusToFahrenheit(20));
    }

    // 2. Verify Fahrenheit to Celsius for known values
    @Test
    void testFahrenheitToCelsius() {
        assertEquals(100.0, converter.fahrenheitToCelsius(212));
        assertEquals(0.0, converter.fahrenheitToCelsius(32));
    }

    // 3. Ensure negative Celsius values convert correctly
    @Test
    void testNegativeCelsius() {
        assertEquals(14.0, converter.celsiusToFahrenheit(-10));
    }

    // 4. Ensure large Fahrenheit values convert correctly
    @Test
    void testLargeFahrenheit() {
        assertEquals(537.78, 
            Math.round(converter.fahrenheitToCelsius(1000) * 100.0) / 100.0);
    }

    // 5. Verify that 0°C equals 32°F
    @Test
    void testZeroCelsiusEquals32Fahrenheit() {
        assertEquals(32.0, converter.celsiusToFahrenheit(0));
    }
}