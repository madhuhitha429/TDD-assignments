package com.example.service;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class EmployeeServiceTest {

    private EmployeeService service = new EmployeeService();

    // 1. Verify that employees with salary > 50,000 are correctly filtered
    @Test
    void testFilterSalaryGreaterThan50000() {

        List<Employee> employees = Arrays.asList(
                new Employee("Madhu", 60000),
                new Employee("Ravi", 40000),
                new Employee("Priya", 70000)
        );

        List<String> result = service.getHighSalaryEmployeeNames(employees);

        assertEquals(2, result.size());
        assertTrue(result.contains("Madhu"));
        assertTrue(result.contains("Priya"));
    }

    // 2. Ensure employees with salary ≤ 50,000 are excluded
    @Test
    void testExcludeSalaryLessThanOrEqual50000() {

        List<Employee> employees = Arrays.asList(
                new Employee("Ravi", 50000),
                new Employee("Anu", 30000)
        );

        List<String> result = service.getHighSalaryEmployeeNames(employees);

        assertTrue(result.isEmpty());
    }

    // 3. Check that the returned list contains only names
    @Test
    void testReturnOnlyNames() {

        List<Employee> employees = Arrays.asList(
                new Employee("Kiran", 80000)
        );

        List<String> result = service.getHighSalaryEmployeeNames(employees);

        assertEquals(1, result.size());
        assertEquals("Kiran", result.get(0));
    }

    // 4. Verify behavior when the employee list is empty
    @Test
    void testEmptyList() {

        List<String> result =
                service.getHighSalaryEmployeeNames(Collections.emptyList());

        assertTrue(result.isEmpty());
    }

    // 5. Verify behavior when all employees meet the salary condition
    @Test
    void testAllEmployeesMeetCondition() {

        List<Employee> employees = Arrays.asList(
                new Employee("A", 60000),
                new Employee("B", 90000)
        );

        List<String> result = service.getHighSalaryEmployeeNames(employees);

        assertEquals(2, result.size());
        assertTrue(result.contains("A"));
        assertTrue(result.contains("B"));
    }
}