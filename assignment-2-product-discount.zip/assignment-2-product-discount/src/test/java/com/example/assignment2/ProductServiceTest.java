package com.example.assignment2;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

public class ProductServiceTest {

    private final ProductService service = new ProductService();

    // 1. Verify that a 10% discount is applied correctly.
    @Test
    void testTenPercentDiscount() {
        Product product = new Product("Laptop", 1000);

        Function<Product, Double> tenPercentDiscount = p -> p.getPrice() * 0.90;

        double discounted = service.applyDiscount(product, tenPercentDiscount);

        assertEquals(900.0, discounted);
    }

    // 2. Ensure that a 0% discount returns the original price.
    @Test
    void testZeroPercentDiscount() {
        Product product = new Product("Phone", 500);

        Function<Product, Double> zeroPercentDiscount = Product::getPrice;

        double discounted = service.applyDiscount(product, zeroPercentDiscount);

        assertEquals(500.0, discounted);
    }

    // 3. Verify behavior when product price is negative (should throw exception).
    @Test
    void testNegativePriceThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Product("Bad", -10));
    }

    // 4. Check that multiple products are discounted correctly using Streams.
    @Test
    void testMultipleProductsDiscountUsingStreams() {
        List<Product> products = Arrays.asList(
                new Product("A", 100),
                new Product("B", 200),
                new Product("C", 300)
        );

        Function<Product, Double> tenPercentDiscount = p -> p.getPrice() * 0.90;

        List<Double> discountedPrices = service.applyDiscountToAll(products, tenPercentDiscount);

        assertEquals(3, discountedPrices.size());
        assertEquals(90.0, discountedPrices.get(0));
        assertEquals(180.0, discountedPrices.get(1));
        assertEquals(270.0, discountedPrices.get(2));
    }

    // 5. Ensure discount function can be swapped dynamically.
    @Test
    void testDiscountFunctionSwapDynamically() {
        Product product = new Product("Tablet", 1000);

        Function<Product, Double> tenPercent = p -> p.getPrice() * 0.90;
        Function<Product, Double> twentyPercent = p -> p.getPrice() * 0.80;

        double price10 = service.applyDiscount(product, tenPercent);
        double price20 = service.applyDiscount(product, twentyPercent);

        assertEquals(900.0, price10);
        assertEquals(800.0, price20);
    }
}