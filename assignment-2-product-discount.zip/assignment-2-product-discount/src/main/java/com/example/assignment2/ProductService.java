package com.example.assignment2;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ProductService {

    // Apply discount to one product using a Function<Product, Double>
    public double applyDiscount(Product product, Function<Product, Double> discountFunction) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (discountFunction == null) {
            throw new IllegalArgumentException("Discount function cannot be null");
        }
        return discountFunction.apply(product);
    }

    // Apply discount to multiple products using Streams
    public List<Double> applyDiscountToAll(List<Product> products, Function<Product, Double> discountFunction) {
        if (products == null) {
            throw new IllegalArgumentException("Products list cannot be null");
        }
        if (discountFunction == null) {
            throw new IllegalArgumentException("Discount function cannot be null");
        }

        return products.stream()
                .map(discountFunction)
                .collect(Collectors.toList());
    }
}