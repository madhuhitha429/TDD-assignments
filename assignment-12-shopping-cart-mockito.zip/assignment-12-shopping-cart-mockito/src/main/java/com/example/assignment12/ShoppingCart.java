package com.example.assignment12;

import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {

    private final Map<String, Double> items = new HashMap<>();
    private final DiscountService discountService;

    public ShoppingCart(DiscountService discountService) {
        this.discountService = discountService;
    }

    public void addItem(String item, double price) {
        items.put(item, price);
    }

    public void removeItem(String item) {
        if (!items.containsKey(item)) {
            throw new IllegalArgumentException("Item not found");
        }
        items.remove(item);
    }

    public double getTotalPrice() {
        return items.values()
                .stream()
                .mapToDouble(Double::doubleValue)
                .sum();
    }

    public double checkout() {
        double total = getTotalPrice();
        double discount = discountService.getDiscountPercentage();
        return total - (total * discount / 100);
    }
}
