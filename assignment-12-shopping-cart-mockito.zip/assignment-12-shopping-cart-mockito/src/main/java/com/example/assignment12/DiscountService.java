package com.example.assignment12;

public interface DiscountService {
    double getDiscountPercentage();
}