package com.example.assignment12;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ShoppingCartTest {

    @Mock
    DiscountService discountService;

    @InjectMocks
    ShoppingCart cart;

    // 1️⃣ Mock 10% discount
    @Test
    void testTenPercentDiscount() {

        when(discountService.getDiscountPercentage()).thenReturn(10.0);

        cart.addItem("Book", 200.0);
        cart.addItem("Pen", 100.0);

        double finalPrice = cart.checkout();

        assertEquals(270.0, finalPrice); // 300 - 10%
    }

    // 2️⃣ Mock 0% discount
    @Test
    void testZeroPercentDiscount() {

        when(discountService.getDiscountPercentage()).thenReturn(0.0);

        cart.addItem("Book", 200.0);

        double finalPrice = cart.checkout();

        assertEquals(200.0, finalPrice);
    }

    // 3️⃣ Mock 50% discount
    @Test
    void testFiftyPercentDiscount() {

        when(discountService.getDiscountPercentage()).thenReturn(50.0);

        cart.addItem("Laptop", 1000.0);

        double finalPrice = cart.checkout();

        assertEquals(500.0, finalPrice);
    }

    // 4️⃣ Verify getDiscountPercentage() called exactly once
    @Test
    void testDiscountCalledOnce() {

        when(discountService.getDiscountPercentage()).thenReturn(10.0);

        cart.addItem("Book", 100.0);

        cart.checkout();

        verify(discountService, times(1)).getDiscountPercentage();
    }

    // 5️⃣ Multiple items + discount
    @Test
    void testMultipleItemsWithDiscount() {

        when(discountService.getDiscountPercentage()).thenReturn(20.0);

        cart.addItem("Item1", 100.0);
        cart.addItem("Item2", 200.0);
        cart.addItem("Item3", 300.0);

        double finalPrice = cart.checkout();

        assertEquals(480.0, finalPrice); // 600 - 20%
    }
}