package com.example.assignment4;

import java.util.List;
import java.util.stream.Collectors;

public class OrderService {

    // Calculate total price of all orders
    public double calculateTotalPrice(List<Order> orders) {
        if (orders == null) {
            throw new IllegalArgumentException("Orders list cannot be null");
        }

        return orders.stream()
                .mapToDouble(Order::getTotalPrice)
                .sum();
    }

    // Filter orders above a certain threshold
    public List<Order> filterOrdersAboveThreshold(List<Order> orders, double threshold) {
        if (orders == null) {
            throw new IllegalArgumentException("Orders list cannot be null");
        }

        return orders.stream()
                .filter(o -> o.getTotalPrice() > threshold)
                .collect(Collectors.toList());
    }
}