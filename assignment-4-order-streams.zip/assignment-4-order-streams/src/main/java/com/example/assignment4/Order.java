package com.example.assignment4;

public class Order {

    private final int id;
    private final double totalPrice;

    public Order(int id, double totalPrice) {
        if (totalPrice < 0) {
            throw new IllegalArgumentException("Order totalPrice cannot be negative");
        }
        this.id = id;
        this.totalPrice = totalPrice;
    }

    public int getId() {
        return id;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}