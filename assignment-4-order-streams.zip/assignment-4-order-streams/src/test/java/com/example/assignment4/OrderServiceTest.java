package com.example.assignment4;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class OrderServiceTest {

    private final OrderService service = new OrderService();

    // 1. Verify that total price is calculated correctly.
    @Test
    void testTotalPriceCalculatedCorrectly() {
        List<Order> orders = Arrays.asList(
                new Order(1, 100.0),
                new Order(2, 200.0),
                new Order(3, 50.0)
        );

        double total = service.calculateTotalPrice(orders);

        assertEquals(350.0, total);
    }

    // 2. Ensure orders above threshold are filtered correctly.
    @Test
    void testFilterOrdersAboveThreshold() {
        List<Order> orders = Arrays.asList(
                new Order(1, 100.0),
                new Order(2, 600.0),
                new Order(3, 499.99),
                new Order(4, 500.01)
        );

        List<Order> filtered = service.filterOrdersAboveThreshold(orders, 500.0);

        assertEquals(2, filtered.size());
        assertTrue(filtered.stream().anyMatch(o -> o.getId() == 2));
        assertTrue(filtered.stream().anyMatch(o -> o.getId() == 4));
    }

    // 3. Verify behavior when no orders exist.
    @Test
    void testNoOrdersExist() {
        double total = service.calculateTotalPrice(Collections.emptyList());
        assertEquals(0.0, total);

        List<Order> filtered = service.filterOrdersAboveThreshold(Collections.emptyList(), 100.0);
        assertTrue(filtered.isEmpty());
    }

    // 4. Check that multiple orders are aggregated correctly.
    @Test
    void testMultipleOrdersAggregatedCorrectly() {
        List<Order> orders = Arrays.asList(
                new Order(1, 10.5),
                new Order(2, 20.25),
                new Order(3, 30.0),
                new Order(4, 40.75)
        );

        double total = service.calculateTotalPrice(orders);

        // 10.5 + 20.25 + 30.0 + 40.75 = 101.5
        assertEquals(101.5, total);
    }

    // 5. Ensure negative order values are handled properly.
    @Test
    void testNegativeOrderValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Order(1, -5.0));
    }
}