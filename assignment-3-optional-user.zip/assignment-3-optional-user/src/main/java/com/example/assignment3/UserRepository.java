package com.example.assignment3;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class UserRepository {

    private final Map<Integer, User> userDatabase = new HashMap<>();

    public UserRepository() {
        // Sample users
        userDatabase.put(1, new User(1, "Alice"));
        userDatabase.put(2, new User(2, "Bob"));
    }

    public Optional<User> findById(int id) {
        return Optional.ofNullable(userDatabase.get(id));
    }
}
