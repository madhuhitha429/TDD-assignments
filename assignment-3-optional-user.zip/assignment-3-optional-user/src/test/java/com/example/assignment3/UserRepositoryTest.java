package com.example.assignment3;

import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class UserRepositoryTest {

    private final UserRepository repository = new UserRepository();

    // 1. Valid ID returns non-empty Optional
    @Test
    void testValidUserIdReturnsNonEmptyOptional() {
        Optional<User> user = repository.findById(1);

        assertTrue(user.isPresent());
        assertEquals("Alice", user.get().getName());
    }

    // 2. Invalid ID returns Optional.empty()
    @Test
    void testInvalidUserIdReturnsEmptyOptional() {
        Optional<User> user = repository.findById(99);

        assertFalse(user.isPresent());
        assertEquals(Optional.empty(), user);
    }

    // 3. Calling get() on empty Optional throws exception
    @Test
    void testGetOnEmptyOptionalThrowsException() {
        Optional<User> user = repository.findById(99);

        assertThrows(java.util.NoSuchElementException.class, user::get);
    }

    // 4. orElse() returns default user
    @Test
    void testOrElseReturnsDefaultUser() {
        User defaultUser = new User(0, "Default");

        User user = repository.findById(99).orElse(defaultUser);

        assertEquals("Default", user.getName());
    }

    // 5. isPresent works correctly
    @Test
    void testIsPresentForValidAndInvalidIds() {
        Optional<User> validUser = repository.findById(1);
        Optional<User> invalidUser = repository.findById(99);

        assertTrue(validUser.isPresent());
        assertFalse(invalidUser.isPresent());
    }
}