package com.example.assignment9;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {

    // 1. Verify initial balance is set correctly
    @Test
    void testInitialBalance() {
        BankAccount account = new BankAccount(1000.0);
        assertEquals(1000.0, account.getBalance());
    }

    // 2. Depositing valid amount increases balance
    @Test
    void testDepositIncreasesBalance() {
        BankAccount account = new BankAccount(500.0);
        account.deposit(200.0);
        assertEquals(700.0, account.getBalance());
    }

    // 3. Depositing negative amount throws exception
    @Test
    void testDepositNegativeThrowsException() {
        BankAccount account = new BankAccount(500.0);
        assertThrows(IllegalArgumentException.class,
                () -> account.deposit(-100.0));
    }

    // 4. Withdrawing valid amount decreases balance
    @Test
    void testWithdrawDecreasesBalance() {
        BankAccount account = new BankAccount(800.0);
        account.withdraw(300.0);
        assertEquals(500.0, account.getBalance());
    }

    // 5. Withdrawing more than balance throws exception
    @Test
    void testWithdrawMoreThanBalanceThrowsException() {
        BankAccount account = new BankAccount(400.0);
        assertThrows(IllegalArgumentException.class,
                () -> account.withdraw(500.0));
    }
}
