package com.example.assignment6;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MultiStudentGradeManagerTest {

    // Verify that multiple students can be added and managed independently.
    @Test
    void testMultipleStudentsIndependent() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        manager.addStudent("Alice");
        manager.addStudent("Bob");

        manager.addMarks("Alice", 80);
        manager.addMarks("Bob", 20);

        assertEquals(80.0, manager.calculateAverage("Alice"));
        assertEquals(20.0, manager.calculateAverage("Bob"));
    }

    // Ensure averages are calculated correctly per student.
    @Test
    void testAveragePerStudent() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        manager.addStudent("Alice");
        manager.addMarks("Alice", 40);
        manager.addMarks("Alice", 60);

        assertEquals(50.0, manager.calculateAverage("Alice"));
    }

    // Confirm that getResult() works correctly for each student.
    @Test
    void testResultPassFailPerStudent() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        manager.addStudent("Alice");
        manager.addStudent("Bob");

        manager.addMarks("Alice", 50);
        manager.addMarks("Alice", 40);

        manager.addMarks("Bob", 10);
        manager.addMarks("Bob", 20);

        assertEquals("PASS", manager.getResult("Alice"));
        assertEquals("FAIL", manager.getResult("Bob"));
    }

    // Check that adding marks to a non-existent student throws an exception.
    @Test
    void testAddMarksToNonExistentStudentThrowsException() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        assertThrows(IllegalArgumentException.class,
                () -> manager.addMarks("Ghost", 50));
    }

    // Verify that getTopper() returns the correct student when multiple students exist.
    @Test
    void testGetTopperReturnsCorrectStudent() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        manager.addStudent("Alice");
        manager.addStudent("Bob");
        manager.addStudent("Charlie");

        manager.addMarks("Alice", 60);     // avg 60
        manager.addMarks("Bob", 90);       // avg 90
        manager.addMarks("Charlie", 75);   // avg 75

        assertEquals("Bob", manager.getTopper());
    }

    // Ensure behavior when no students are added.
    @Test
    void testNoStudentsAdded() {
        MultiStudentGradeManager manager = new MultiStudentGradeManager();

        assertNull(manager.getTopper());
    }
}