package com.example.assignment6;

import java.util.ArrayList;
import java.util.List;

public class StudentGradeCalculator {

    private final List<Integer> marks = new ArrayList<>();

    public void addMarks(int marks) {
        if (marks < 0) {
            throw new IllegalArgumentException("Marks cannot be negative");
        }
        this.marks.add(marks);
    }

    public double calculateAverage() {
        if (marks.isEmpty()) {
            return 0.0;
        }
        int sum = 0;
        for (int m : marks) {
            sum += m;
        }
        return (double) sum / marks.size();
    }

    public String getResult() {
        return calculateAverage() >= 40 ? "PASS" : "FAIL";
    }
}