package com.example.assignment6;

import java.util.HashMap;
import java.util.Map;

public class MultiStudentGradeManager {

    private final Map<String, StudentGradeCalculator> students = new HashMap<>();

    public void addStudent(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Student name cannot be empty");
        }
        if (students.containsKey(name)) {
            throw new IllegalArgumentException("Student already exists: " + name);
        }
        students.put(name, new StudentGradeCalculator());
    }

    public void addMarks(String name, int marks) {
        StudentGradeCalculator calc = students.get(name);
        if (calc == null) {
            throw new IllegalArgumentException("Student not found: " + name);
        }
        calc.addMarks(marks);
    }

    public double calculateAverage(String name) {
        StudentGradeCalculator calc = students.get(name);
        if (calc == null) {
            throw new IllegalArgumentException("Student not found: " + name);
        }
        return calc.calculateAverage();
    }

    public String getResult(String name) {
        StudentGradeCalculator calc = students.get(name);
        if (calc == null) {
            throw new IllegalArgumentException("Student not found: " + name);
        }
        return calc.getResult();
    }

    public String getTopper() {
        if (students.isEmpty()) {
            return null; // behavior when no students are added
        }

        String topperName = null;
        double bestAvg = -1;

        for (Map.Entry<String, StudentGradeCalculator> entry : students.entrySet()) {
            double avg = entry.getValue().calculateAverage();
            if (avg > bestAvg) {
                bestAvg = avg;
                topperName = entry.getKey();
            }
        }
        return topperName;
    }
}