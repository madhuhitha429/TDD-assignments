package com.example.assignment6;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import java.util.stream.Stream;

public class StudentGradeParameterizedTest {

    // 1️⃣ Use @ValueSource to verify valid marks do not throw exceptions
    @ParameterizedTest
    @ValueSource(ints = {10, 40, 75, 100})
    @DisplayName("Valid marks should not throw exception")
    void testValidMarks(int mark) {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        Assertions.assertDoesNotThrow(() -> calculator.addMarks(mark));
    }

    // 2️⃣ Use @CsvSource to test multiple sets of marks and expected averages
    @ParameterizedTest
    @CsvSource({
            "40,60,50",
            "20,30,25",
            "80,100,90"
    })
    @DisplayName("Average calculation test")
    void testAverageCalculation(int mark1, int mark2, double expectedAverage) {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        calculator.addMarks(mark1);
        calculator.addMarks(mark2);

        Assertions.assertEquals(expectedAverage, calculator.calculateAverage());
    }

    // 3️⃣ Use @CsvSource to test PASS/FAIL results
    @ParameterizedTest
    @CsvSource({
            "50,60,PASS",
            "20,30,FAIL",
            "40,40,PASS",
            "39,39,FAIL"
    })
    @DisplayName("PASS/FAIL result test")
    void testPassFail(int mark1, int mark2, String expectedResult) {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        calculator.addMarks(mark1);
        calculator.addMarks(mark2);

        Assertions.assertEquals(expectedResult, calculator.getResult());
    }

    // 4️⃣ Use @ValueSource to confirm negative marks throw exception
    @ParameterizedTest
    @ValueSource(ints = {-1, -10, -100})
    @DisplayName("Negative marks should throw exception")
    void testNegativeMarks(int mark) {
        StudentGradeCalculator calculator = new StudentGradeCalculator();
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> calculator.addMarks(mark));
    }

    // 5️⃣ Use @MethodSource for complex test data (multiple marks)
    @ParameterizedTest
    @MethodSource("provideMultipleMarks")
    @DisplayName("Complex multiple marks average test")
    void testMultipleMarks(int[] marks, double expectedAverage) {
        StudentGradeCalculator calculator = new StudentGradeCalculator();

        for (int mark : marks) {
            calculator.addMarks(mark);
        }

        Assertions.assertEquals(expectedAverage, calculator.calculateAverage());
    }

    static Stream<Arguments> provideMultipleMarks() {
        return Stream.of(
                Arguments.of(new int[]{50, 60, 70}, 60.0),
                Arguments.of(new int[]{10, 20, 30}, 20.0),
                Arguments.of(new int[]{40, 40, 40}, 40.0)
        );
    }
}